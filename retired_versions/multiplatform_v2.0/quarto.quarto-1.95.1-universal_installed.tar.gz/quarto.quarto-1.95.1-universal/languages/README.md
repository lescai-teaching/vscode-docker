We've incorporated code from several other extensions to provide features for LaTeX, Mermaid, and Graphviz:

- LaTeX code completion, preview, and language support from https://github.com/James-Yu/LaTeX-Workshop

- Graphviz language support from https://github.com/Stephanvs/vscode-graphviz

- Mermaid language support from https://github.com/bpruitt-goddard/vscode-mermaid-syntax-highlight
  (fork maintained at https://github.com/quarto-dev/vscode-mermaid-syntax-highlight)
